#!/usr/bin/python3

import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLCDNumber, QGridLayout, QPushButton, QVBoxLayout

class Calculator(QWidget):

    def __init__(self):
        super().__init__()
        self.initIU()

    def initIU(self):
        vbox=QVBoxLayout()
        grid=QGridLayout()
        num=QLCDNumber(self)
        vbox.addWidget(num)
        vbox.addLayout(grid)
        self.setLayout(vbox)


        names=['Cls','Bck','Err','Close','7','8','9','/','4','5','6','*','1','2','3','-','0','.','=','+']
        positions=[(i,j) for i in range(5) for j in range(4)]

        for position, name in zip(positions,names):
            self.button=QPushButton(name,self)
            grid.addWidget(self.button,*position)

        self.button.clicked.connect(self.doSomething())
        #grid.addWidget(num,6,0,1,4)

        self.setGeometry(400,600,300,300)
        self.setWindowTitle("КальклоЭ")

    def doSomething(self):
        saaaaaaaaaaa=QPushButton(self.button)
        print(saaaaaaaaaaa)


if __name__ == '__main__':
    app=QApplication(sys.argv)
    Calc=Calculator()
    Calc.show()
    sys.exit(app.exec_())
